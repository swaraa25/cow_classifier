# `models` folder
Make sure this folder contains these two files:
1.  `classes.txt`
2.  `model.pkl`

Our versions of these two files can be downloaded here from .       

**Drive**:      

`wget "https://drive.google.com/u/0/uc?id=1yPDtQXfaCvGU5YJPyMX6qQm9rq_LWuKU&export=download"`
  
`wget "https://drive.google.com/u/0/uc?id=1nSN9SpDJEAHe4pCmKWy0X7oCPyx4BrjT&export=download"`
